just run the code would reproduce the best result I submitted on kaggle
I wish I had adjust to the specific hyperparameters I used to reach the baselines. 
